
CREATE OR REPLACE PROCEDURE insert_invoice_with_items (
    p_buyer_name     IN VARCHAR2,
    p_seller_name    IN VARCHAR2,
    p_invoice_date   IN DATE,
    p_items          IN invoice_item_tab
)
IS
    v_invoice_id NUMBER;
BEGIN
    SELECT INVOICE_SEQ.NEXTVAL INTO v_invoice_id FROM dual;

    INSERT INTO INVOICE (ID, BUYER, SELLER, DATE_CREATED)
    VALUES (v_invoice_id, p_buyer_name, p_seller_name, p_invoice_date);

    FOR i IN 1 .. p_items.COUNT LOOP
        INSERT INTO INVOICE_ITEMS (
            ITEM_ID, INVOICE_ID, NAME, QUANTITY, RATE, AMOUNT
        ) VALUES (
            ITEM_SEQ.NEXTVAL,
            v_invoice_id,
            p_items(i).item_name,
            p_items(i).quantity,
            p_items(i).rate,
            p_items(i).amount
        );
    END LOOP;
END;
/

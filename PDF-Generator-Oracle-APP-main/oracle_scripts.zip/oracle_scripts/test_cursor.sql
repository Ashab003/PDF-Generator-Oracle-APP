
SET SERVEROUTPUT ON;
DECLARE
    CURSOR item_cursor IS
        SELECT NAME, QUANTITY, RATE, AMOUNT
        FROM INVOICE_ITEMS
        WHERE INVOICE_ID = 101;

BEGIN
    FOR item IN item_cursor LOOP
        DBMS_OUTPUT.PUT_LINE('Item: ' || item.NAME || ', Qty: ' || item.QUANTITY ||
                             ', Rate: ' || item.RATE || ', Amount: ' || item.AMOUNT);
    END LOOP;
END;
/

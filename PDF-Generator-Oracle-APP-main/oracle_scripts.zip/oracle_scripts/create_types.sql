
CREATE OR REPLACE TYPE invoice_item_obj AS OBJECT (
    item_name  VARCHAR2(100),
    quantity   NUMBER,
    rate       NUMBER,
    amount     NUMBER
);
/
CREATE OR REPLACE TYPE invoice_item_tab AS TABLE OF invoice_item_obj;
/

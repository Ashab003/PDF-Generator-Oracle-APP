
CREATE OR REPLACE FUNCTION get_invoice_total(p_invoice_id IN NUMBER)
RETURN NUMBER
IS
    v_total NUMBER;
BEGIN
    SELECT SUM(AMOUNT)
    INTO v_total
    FROM INVOICE_ITEMS
    WHERE INVOICE_ID = p_invoice_id;

    RETURN NVL(v_total, 0);
END;
/
